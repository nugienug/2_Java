package com.java.nestedclass;

public class OuterClass {
	
	static private int initial=5;
	
	static class InnerClass{
		public void add(int num) {
			System.out.println(num+initial);
		}
	}
}
