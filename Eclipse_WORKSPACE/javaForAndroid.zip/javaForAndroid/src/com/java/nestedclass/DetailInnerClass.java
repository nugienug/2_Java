package com.java.nestedclass;

public class DetailInnerClass extends OuterClass{

}
