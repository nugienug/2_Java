package com.java.innerClass;

public class Button extends ClickEvent {

}
