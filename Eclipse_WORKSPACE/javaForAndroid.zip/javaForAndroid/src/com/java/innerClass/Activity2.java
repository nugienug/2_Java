package com.java.innerClass;

public class Activity2  {
	Button button = new Button();
	Switch switctButton = new Switch();
	
	public Activity2() {
		
		button.setOnClickListner(new ClickEvent.Listner() {
			@Override
			public void click() {
				System.out.println("Activity2 button clicked");
			}
		});
		
		switctButton.setOnClickListner(new ClickEvent.Listner() {
			@Override
			public void click() {
				System.out.println("Activity2 switctButton clicked");
			}
		});
	}
}
