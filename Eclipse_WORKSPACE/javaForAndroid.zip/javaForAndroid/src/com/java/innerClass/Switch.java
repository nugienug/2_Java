package com.java.innerClass;

public class Switch extends ClickEvent{

}
