package com.java.innerClass;

public class MainClass {

	public static void main(String[] args) {
		Activity activity1  = new Activity();
		activity1.button.click();
		activity1.switctButton.click();
		
		Activity2 activity2  = new Activity2();
		activity2.button.click();
		activity2.switctButton.click();
	}
}
