package com.java.innerClass;

public class ClickEvent {

	private Listner listner;

	public void setOnClickListner(Listner listner) {
		this.listner = listner;
	}

	public void click() {
		listner.click();
	}

	static interface Listner {
		public void click() ;
	}

}
