package com.java.anonymous;

public class DetailAnonymous extends Anonymous{

	@Override
	public void add(int num) {
		System.out.println(num+startNum);
		
	}

}
