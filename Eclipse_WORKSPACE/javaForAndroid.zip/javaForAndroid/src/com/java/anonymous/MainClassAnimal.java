package com.java.anonymous;

public class MainClassAnimal {

	public static void main(String[] args) {
		Animal dog = (int num, int num2) ->{System.out.println("Ramda1. Dog"+num+num2);};
		dog.speak(1,2);
		
		
		Animal dog2 = (int num, int num2)->System.out.println("Ramda2. Dog"+num+num2);
		dog2.speak(1,2);
		
		Animal dog4 = new Animal() {
			@Override
			public void speak(int num, int num2) {
				System.out.println("Ramda2. Dog"+num+num2);
				
			}
		};
		dog4.speak(1, 2);
		
		
		
		
		
		
		
		
//		
//		Animal dog3 =  System.out::println;
//		
//		Animal realDog1 = new Dog();
//		Animal realDog2 = new Dog();
//		Animal realDog3 = new Dog();
//		realDog1.speak();
//		realDog2.speak();
//		realDog3.speak();
	}
	

	
}
