package com.java.anonymous;

public interface  Animal {
	public void speak(int num, int num2);
}
