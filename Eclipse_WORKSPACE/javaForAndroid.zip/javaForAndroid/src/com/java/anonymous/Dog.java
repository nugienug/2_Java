package com.java.anonymous;

public class Dog implements Animal{

	@Override
	public void speak(int num, int num2) {
		System.out.println("Dog");
	}

}
