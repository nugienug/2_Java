package com.java.anonymous;

public abstract class Anonymous {

	public int startNum=5;
	abstract public void add(int num);
	
}
