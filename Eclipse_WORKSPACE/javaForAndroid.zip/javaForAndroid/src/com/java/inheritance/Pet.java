package com.java.inheritance;

public interface Pet {

	public String speak() ;
}
