package com.java.inheritance;

public class Cat extends Animal{

	@Override
	public String speak() {
		// TODO Auto-generated method stub
		return "Cat";
	}
}
