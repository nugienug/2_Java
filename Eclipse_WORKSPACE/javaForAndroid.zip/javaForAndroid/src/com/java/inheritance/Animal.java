package com.java.inheritance;

public class Animal {
  
		public String name;
		public String color;
		int age;
	
		public String speak() {
			return "Animal";
		}
		
		public void eat() {
			
		}
		
		public void sleep() {
			
		}
}
