package com.java.inheritance;

public interface Creature {

	public String speak();
}
