package com.java.inheritance;

public class Dog extends Animal implements Pet, Creature{

	@Override
	public String speak() {
		return "Dog";
	}
}
